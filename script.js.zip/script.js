 $(document).ready(function() {
             
                  $("body").on('click','.button_remove', function(){
                  //alert('aaa');
                  idButton=$(this).attr('id');
                    //alert(idButton);
                  divId="div_"+idButton;
                  
                  $("."+divId).remove();
                  $("#table_"+idButton).remove();
                  $("#"+idButton).remove();
              });
     
     
            $("#tables").change(function() {//добавление таблицы из БД из списка
                var optionID = $('#tables option:selected').attr('id');
                //alert(optionID);
                lastId=0;
                colRows=11;
                value=$('#tables option:selected').val();
                $.post('block.php', {old_table_id:colRows}, function(data){
                        obj=JSON.parse(data);
                        lastId=obj[0];
                    });
                
                $.post('block.php', {table_id:optionID}, function(data) {
                    //alert(optionID);
                    $("#"+optionID).attr('disabled', true);
                    lastName=$(".input_names:last").attr('name')+"";
                    names=lastName.split('_');
                    if(names[1]>0){
                        lastId=names[1]+1;
                    }
                    $("#td_table").append("<textarea name='table_"+lastId+"' id='table_"+lastId+"'>"+value+"</textarea>");
                   obj=JSON.parse(data);
                    //$("#strings>option").remove();
                    i=0;
                    for(var keyss in obj){
                        //alert(lastId+"---"+keyss+"---"+obj[keyss]);
                        $("#td_table").append("<div class='div_"+lastId+"'><br>Название:<input type='text' name='name_"+lastId+"_"+i+"' value='"+obj[keyss]+"' class='input_names'><br><br><select name='select_"+lastId+"_"+i+"' ><option value='textarea'>Текст</option><option value='file'>Файл</option></select></div>");
                        i++;
                    }//Значение: <textarea name='value_"+lastId+"_"+keyss+"'></textarea>
                    $("#td_table").append("<input type='button' id='"+lastId+"' value='удалить таблицу' class='button_remove'>");
                    

                });
            });
             
         
                  
                  
                  
                  
                  
            $("#button_add").click(function(){//добавление таблицу добавленной пользователем
                tableName=$("#tables_name").val();
                colRows=$("#col_columns").val();
                //alert(tableName+"--"+colRows);
                $.post('block.php', {old_table_id:colRows}, function(data){
                    obj=JSON.parse(data);
                    //alert(obj[0]);
                    lastId=obj[0];
                    lastName=$(".input_names:last").attr('name')+"";
                    names=lastName.split('_');
                    if(names[1]>0){
                        lastId=names[1]+1;
                    }
                    $("#td_table").append("<textarea name='table_"+lastId+"' id='table_"+lastId+"'>"+tableName+"</textarea>");
                    for(i=0;i<colRows;i++){
                        $("#td_table").append("<div class='div_"+lastId+"'><br>Название:<input type='text' name='name_"+lastId+"_"+i+"' class='input_names'><select name='select_"+lastId+"_"+i+"'><option value='textarea'>Текст</option><option value='file'>Файл</option></select><br></div>");//Значение: <textarea name='value_"+lastId+"_"+i+"'></textarea>
                    }
                    $("#td_table").append("<input type='button' id='"+lastId+"' value='удалить таблицу' class='button_remove'>");
                });
            });
        });